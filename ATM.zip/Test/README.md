# ATM System

# Requirements
- Deposit
- Withdraw
- Check Balance
- Convert currency

# To begin, handle usecase for 1 user




