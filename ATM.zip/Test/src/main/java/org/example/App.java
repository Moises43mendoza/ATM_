package org.example;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner myobj = new Scanner(System.in);
        double choice = 0;
        double balance = 3422.90;

        while (choice != 4)
            {
                System.out.println("Welcome back to Goliath National Bank Moises!");
                System.out.println("What would you like to do today?");
                System.out.println("1) Withdraw");
                System.out.println("2) Deposit");
                System.out.println("3) Check Balance");
                System.out.println("4) Exit");
                choice = myobj.nextDouble();

                if (choice == 1)
                {
                    System.out.println("How much would you like to Withdraw?");
                    balance = balance - myobj.nextDouble();
                }

                if (choice ==2)
                {
                    System.out.println("How much would you like to Deposit?");
                    balance = balance + myobj.nextDouble();
                }

                if (choice == 3)
                {
                    System.out.println("Your balance is: ");
                    System.out.println(balance);
                    System.out.println("Input any number to continue...");
                    myobj.nextDouble();

                }

        }

    }
}

/*
- Deposit
- Withdraw
- Check Balance
- Convert currency
 */



